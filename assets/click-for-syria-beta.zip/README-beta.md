# Click for Syria — Beta

**Click for Syria** is a Chrome extension that detects when you visit a platform that blocks Syrian users and lets you take action in seconds — send an email to their team, message them on LinkedIn, or generate an Instagram post calling them out.

The US lifted sanctions on Syria in December 2025. ChatGPT, Figma, PayPal, Slack, and others still haven't updated their policies. This extension makes it effortless to reach the people who can actually change that.

To learn more, visit [clickforsyria.com](https://clickforsyria.com) or [unblocksyria.com](https://unblocksyria.com).

---

## Installing the Beta

This is a pre-release beta. It isn't on the Chrome Web Store yet, so you'll need to load it manually in developer mode. It takes about 30 seconds.

1. **Extract this zip** to a folder on your computer.
2. **Open Chrome** and go to `chrome://extensions/`.
3. **Enable Developer Mode** — toggle it on in the top-right corner.
4. **Click "Load unpacked"** and select the `dist` folder inside the extracted folder.

The extension is now installed. Visit ChatGPT, Figma, PayPal, or any of the other supported platforms and the overlay will appear automatically.

---

## Supported Platforms

OpenAI · ChatGPT · Figma · Gemini · PayPal · Anthropic · Claude · Slack · Udemy · Apple App Store · Coursera · GitLab

---

## Feedback

Found a bug or have a suggestion? Open an issue on GitHub:
[github.com/farissiddiqui/click-for-syria](https://github.com/farissiddiqui/click-for-syria)
